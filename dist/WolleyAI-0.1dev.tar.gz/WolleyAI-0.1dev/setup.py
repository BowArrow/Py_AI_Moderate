from distutils.core import setup

setup(
    name='WolleyAI',
    version='0.1dev',
    packages=['WolleyAI'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read()
)